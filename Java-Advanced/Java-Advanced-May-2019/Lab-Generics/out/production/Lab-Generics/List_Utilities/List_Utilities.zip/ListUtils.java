import java.util.List;

public class ListUtils<T> {
    public static <T extends Comparable<T> > T getMin(List<T> list) throws IllegalAccessException {
        if (list.isEmpty()) {
            throw new IllegalAccessException();
        }

        T minElement = list.get(0);

        for (T element : list) {
            if (minElement.compareTo(element) > 0) {
                minElement = element;
            }
        }

        return minElement;
    }

    public static <T extends Comparable<T> > T getMax(List<T> list) throws IllegalAccessException {
        if (list.isEmpty()) {
            throw new IllegalAccessException();
        }
        T minElement = list.get(0);

        for (T element : list) {
            if (minElement.compareTo(element) < 0) {
                minElement = element;
            }
        }

        return minElement;
    }
}
