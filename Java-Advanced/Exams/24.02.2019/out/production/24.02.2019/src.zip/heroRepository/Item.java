package heroRepository;

public class Item {
    private int strength;
    private int agility;
    private int intelligence;

    public Item(int strength, int agility, int intelligence) {
        this.strength = strength;
        this.agility = agility;
        this.intelligence = intelligence;
    }

    public int getStrength() {
        return strength;
    }

    public int getAgility() {
        return agility;
    }

    public int getIntelligence() {
        return intelligence;
    }

    @Override
    public String toString() {
        String result = "Item:" + System.lineSeparator();
        result += "  *  Strength: " + this.strength + System.lineSeparator();
        result += "  *  Agility: " + this.agility + System.lineSeparator();
        result += "  *  Intelligence: " + this.intelligence;
        return result;
    }
}
