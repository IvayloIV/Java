import heroRepository.Hero;
import heroRepository.HeroRepository;
import heroRepository.Item;

public class Main {
    public static void main(String[] args) {
        HeroRepository repository = new HeroRepository();
        Item item1 = new Item(43, 54, 54);
        Item item2 = new Item(11, 14, 66);
        Hero hero = new Hero("Hero Name1", 24, item1);
        Hero hero2 = new Hero("Hero Name2", 43, item2);
        repository.add(hero);
        repository.add(hero2);

        System.out.println(repository.getHeroWithHighestAgility());
    }
}
