package Ferrari;

public interface Car {
    public abstract String brakes();

    public abstract String gas();
}
